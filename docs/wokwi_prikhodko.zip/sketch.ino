
// определение пинов
const int PIN_MQ2 = A0;   // Датчик 1: Аналоговый MQ2 (Задымленность)
const int PIN_LDR = A1;   // Датчик 2: Аналоговый LDR (Освещенность)
const int PIN_SW = 2;     // Датчик 3: Цифровой SW (Дверь)
const int PIN_BUZZER = 8; // Исполнительное устройство: Зуммер
const int PIN_LED = 13;   // Светодиод-индикатор: Зеленый

// параметры варианта
const unsigned long PERIOD = 2000;   // Период опроса Т = 2 секунды
const float THRESHOLD_VAL = 40.0;    // Порог события: задымленность > 40%

// системные переменные
unsigned long lastMillis = 0;
unsigned long measurementCount = 0;
bool eventActive = false; // Хранит состояние: зафиксировано ли превышение порога

void setup() {
  Serial.begin(9600);
  
  // настройка пинов
  pinMode(PIN_SW, INPUT_PULLUP); // Используем внутреннюю подтяжку по заданию
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_LED, OUTPUT);
  
  digitalWrite(PIN_BUZZER, LOW);
  digitalWrite(PIN_LED, LOW);
}

void loop() {
  // соблюдение периода опроса в 2 секунды
  if (millis() - lastMillis >= PERIOD) {
    lastMillis += PERIOD;
    measurementCount++;

    // чтение и расчет датчика 1 (MQ2: задымленность 0-100%)
    int rawMQ2 = analogRead(PIN_MQ2);
    // 0-1023 переводим в 0.0-100.0%
    float s1 = (rawMQ2 / 1023.0) * 100.0; 

    // чтение и расчет датчика 2 (LDR: освещенность 0-100%)
    int rawLDR = analogRead(PIN_LDR);
    // 0-1023 переводим в 0.0-100.0%
    float s2 = (rawLDR / 1023.0) * 100.0;

    // чтение датчика 3 (SW: дверь, 0 или 1) ---
    // SW замкнут на GND (выдает 0), значит сработал (дверь открыта -> 1)
    // печатаем инвертированное значение
    int s3 = (digitalRead(PIN_SW) == LOW) ? 1 : 0; 

    // вывод строки DATA
    Serial.print("DATA n=");
    Serial.print(measurementCount);
    Serial.print(" s1=");
    Serial.print(s1, 2); // Не более двух знаков после запятой
    Serial.print(" s2=");
    Serial.print(s2, 2);
    Serial.print(" s3=");
    Serial.println(s3);

    // проверка порога события (задымленность > 40%)
    if (s1 > THRESHOLD_VAL) {
      if (!eventActive) {
        eventActive = true;
        
        // включаем индикацию и зуммер
        digitalWrite(PIN_LED, HIGH);
        tone(PIN_BUZZER, 1000); 
        
        // вывод строки EVENT (один раз при переходе порога)
        Serial.print("EVENT n=");
        Serial.print(measurementCount);
        Serial.println(" type=THRESHOLD");
      }
    } else {
      if (eventActive) {
        eventActive = false;
        
        // выключаем индикацию и зуммер
        digitalWrite(PIN_LED, LOW);
        noTone(PIN_BUZZER);
        
        // вывод строки EVENT (один раз при возвращении в норму)
        Serial.print("EVENT n=");
        Serial.print(measurementCount);
        Serial.println(" type=NORMAL");
      }
    }
  }
}
